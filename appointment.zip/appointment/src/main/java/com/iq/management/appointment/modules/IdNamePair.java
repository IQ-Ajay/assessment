package com.iq.management.appointment.modules;

import lombok.Builder;

@Builder
public record IdNamePair(
        int id,
        String name
) {
}
