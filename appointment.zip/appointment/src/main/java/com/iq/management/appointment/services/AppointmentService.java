package com.iq.management.appointment.services;

import com.iq.management.appointment.database.Tables;
import com.iq.management.appointment.database.tables.records.AppointmentRecord;
import com.iq.management.appointment.modules.AppointmentDetails;
import com.iq.management.appointment.modules.SaveAppointment;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.impl.DSL;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AppointmentService {
    private final DSLContext context;
    private final DoctorService doctorService;
    private final PatientService patientService;


    public List<AppointmentDetails> getAllAppointments() {
        return this.context.selectFrom(Tables.APPOINTMENT).where(Tables.APPOINTMENT.IS_DELETED.eq(false)).stream().map(appointmentRecord -> AppointmentDetails.builder()
                .appointmentId(appointmentRecord.getId())
                .notes(appointmentRecord.getNotes())
                .title(appointmentRecord.getTitle())
                .doctor(doctorService.getDoctorById(appointmentRecord.getDoctorId()).name())
                .patient(patientService.getPatientById(appointmentRecord.getPatientId()).name())
                .targetDate(appointmentRecord.getTargetDate())
                .build()).toList();
    }

    public AppointmentDetails getAppointmentById(Integer id){
        AppointmentRecord appointmentRecord = this.context.selectFrom(Tables.APPOINTMENT).where(Tables.APPOINTMENT.ID.eq(id).and(Tables.APPOINTMENT.IS_DELETED.eq(false))).fetchOne();
        return AppointmentDetails.builder()
                .appointmentId(appointmentRecord.getId())
                .notes(appointmentRecord.getNotes())
                .title(appointmentRecord.getTitle())
                .doctor(doctorService.getDoctorById(appointmentRecord.getDoctorId()).name())
                .patient(patientService.getPatientById(appointmentRecord.getPatientId()).name())
                .targetDate(appointmentRecord.getTargetDate())
                .build();

    }

    public void saveAppointment(SaveAppointment saveAppointment) {
        AppointmentRecord appointmentRecord = this.context.newRecord(Tables.APPOINTMENT);
        appointmentRecord.setDoctorId(saveAppointment.doctorId());
        appointmentRecord.setPatientId(saveAppointment.patientId());
        appointmentRecord.setTitle(saveAppointment.title());
        appointmentRecord.setCreatedOn(LocalDateTime.now());
        appointmentRecord.setUpdatedOn(LocalDateTime.now());
        appointmentRecord.store();
    }

    public void updateAppointment(Integer id,SaveAppointment saveAppointment) {
        AppointmentRecord appointmentRecord = this.context.selectFrom(Tables.APPOINTMENT).where(Tables.APPOINTMENT.ID.eq(id)).fetchOne();
        if(appointmentRecord == null) return;
        appointmentRecord.setDoctorId(saveAppointment.doctorId());
        appointmentRecord.setPatientId(saveAppointment.patientId());
        appointmentRecord.setTitle(saveAppointment.title());
        appointmentRecord.setCreatedOn(LocalDateTime.now());
        appointmentRecord.setUpdatedOn(LocalDateTime.now());
        appointmentRecord.update();
    }
    public void deleteAppointment(Integer id) {
        AppointmentRecord appointmentRecord = this.context.selectFrom(Tables.APPOINTMENT).where(Tables.APPOINTMENT.ID.eq(id)).fetchOne();
        if(appointmentRecord == null) return;
        appointmentRecord.setIsDeleted(true);
        appointmentRecord.update();
    }
}
