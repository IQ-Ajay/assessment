package com.iq.management.appointment.services;

import com.iq.management.appointment.database.Tables;
import com.iq.management.appointment.database.tables.records.PatientRecord;
import com.iq.management.appointment.modules.IdNamePair;
import org.jooq.DSLContext;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {
    private  DSLContext context;
    public List<IdNamePair> getAllPatients(){
        return this.context.selectFrom(Tables.PATIENT).stream().map(patientRecord -> IdNamePair.builder()
                .id(patientRecord.getId())
                .name(patientRecord.getName()).build()).toList();
    }
    public IdNamePair getPatientById(int id){
        PatientRecord patientRecord = this.context.selectFrom(Tables.PATIENT).where(Tables.PATIENT.ID.eq(id)).fetchOne();
        if(patientRecord != null)
        return IdNamePair.builder().id(patientRecord.getId()).name(patientRecord.getName()).build();
        return null;
    }
}
