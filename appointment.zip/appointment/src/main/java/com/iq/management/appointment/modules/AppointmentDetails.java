package com.iq.management.appointment.modules;

import lombok.Builder;

import java.time.LocalDateTime;

@Builder
public record AppointmentDetails(
        int appointmentId,
        String title,
        String patient,
        String doctor,
        LocalDateTime targetDate,
        String notes
) {
}
