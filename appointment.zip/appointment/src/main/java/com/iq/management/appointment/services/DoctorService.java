package com.iq.management.appointment.services;

import com.iq.management.appointment.database.Tables;
import com.iq.management.appointment.database.tables.records.DoctorRecord;
import com.iq.management.appointment.database.tables.records.PatientRecord;
import com.iq.management.appointment.modules.IdNamePair;
import org.jooq.DSLContext;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {
    private DSLContext context;
    public List<IdNamePair> getAllDoctors(){
        return this.context.selectFrom(Tables.DOCTOR).stream().map(patientRecord -> IdNamePair.builder()
                .id(patientRecord.getId())
                .name(patientRecord.getName()).build()).toList();
    }
    public IdNamePair getDoctorById(int id){
        DoctorRecord doctorRecord = this.context.selectFrom(Tables.DOCTOR).where(Tables.DOCTOR.ID.eq(id)).fetchOne();
        if(doctorRecord != null)
            return IdNamePair.builder().id(doctorRecord.getId()).name(doctorRecord.getName()).build();
        return null;
    }
}
