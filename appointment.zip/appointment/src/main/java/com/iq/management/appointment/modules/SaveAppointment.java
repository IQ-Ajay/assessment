package com.iq.management.appointment.modules;

import lombok.Builder;

import java.time.LocalDateTime;

@Builder
public record SaveAppointment(
      String title,
      int patientId,
      int doctorId,
      LocalDateTime targetDate
) {
}
