package com.iq.management.appointment.controllers;

import com.iq.management.appointment.modules.AppointmentDetails;
import com.iq.management.appointment.modules.SaveAppointment;
import com.iq.management.appointment.services.AppointmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*", maxAge = 36000)

public class AppointmentController {

    private final AppointmentService appointmentService;
    @GetMapping()
    public List<AppointmentDetails> getAllAppointments(){
        return this.appointmentService.getAllAppointments();
    }
    @GetMapping("/{id}")
    public AppointmentDetails getAppointmentById(@PathVariable Integer id){
        return this.appointmentService.getAppointmentById(id);
    }
    @PostMapping
    public void saveAppointment(@RequestBody SaveAppointment saveAppointment){
        this.appointmentService.saveAppointment(saveAppointment);
    }
    @PutMapping("/{id}")
    public void updateAppointment(@PathVariable Integer id,@RequestBody SaveAppointment saveAppointment){
        this.appointmentService.updateAppointment(id,saveAppointment);
    }
    @DeleteMapping("/{id}")
    public void deleteAppointment(@PathVariable Integer id ){
        this.appointmentService.deleteAppointment(id);
    }
}
