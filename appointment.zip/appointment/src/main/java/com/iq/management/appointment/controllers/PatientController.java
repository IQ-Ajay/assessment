package com.iq.management.appointment.controllers;

import com.iq.management.appointment.modules.IdNamePair;
import com.iq.management.appointment.services.PatientService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 36000)
@RestController
@RequestMapping("/patient")
@RequiredArgsConstructor

public class PatientController {
    private final PatientService patientService;

    @GetMapping("/{id}")
    public IdNamePair getPatientById(@PathVariable Integer id) {
        return this.patientService.getPatientById(id);
    }

    @GetMapping("/all")
    public List<IdNamePair> getAllPatients() {
        return this.patientService.getAllPatients();
    }
}
