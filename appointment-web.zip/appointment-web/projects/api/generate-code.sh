
java -jar  ./swagger-codegen/swagger-codegen-cli-3.0.59.jar generate -i http://localhost:8080/api-docs -l typescript-angular -o ./src/lib