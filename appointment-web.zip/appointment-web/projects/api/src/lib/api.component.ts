import { Component } from '@angular/core';

@Component({
  selector: 'lib-api',
  standalone: true,
  imports: [],
  template: `
    <p>
      api works!
    </p>
  `,
  styles: ``
})
export class ApiComponent {

}
