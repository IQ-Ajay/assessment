import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'appointment-web';
  constructor(private http: HttpClient){}
  ngOnInit(){
    this.http.get('http://localhost:8080/appointments')
  .subscribe(response => {
    this.rowData = response;
  });
  }

rowData:any = [
    { id:1, title: "1 on 1", notes: "Any notes", patient: "John Doe", doctor: "Cody Fisher" , targetDate:"2020-10-07" },
    { id:2, title: "1 on 1", notes: "Any notes", patient: "John Doe", doctor: "Cody Fisher" , targetDate:"2020-10-07" },
    { id:3, title: "1 on 1", notes: "Any notes", patient: "John Doe", doctor: "Cody Fisher" , targetDate:"2020-10-07" },
  ];

}
